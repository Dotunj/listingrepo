<script src="/admin/assets/vendor/jquery/jquery.min.js"></script>
<script src="/admin/assets/vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="/admin/assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<script src="/admin/assets/multiple-select/multiple-select.js"></script>
<script src="/admin/assets/scripts/klorofil-common.js"></script>
</body>
</html>